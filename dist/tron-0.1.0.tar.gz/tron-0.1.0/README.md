# TRON Python SDK

TRON is a local-first Python distributed execution runtime.

This package publishes only the client-side SDK:

- `tron` package: decorators, client, remote execution API, SDK helpers
- `tkron` compatibility layer

The runtime implementation (`queue_server.py`, `worker.py`, and other server/worker files) is intentionally not distributed.

## Install

```bash
pip install tron
```

## Use

```python
import tron

@tron.remote
def add_numbers(a, b):
    return a + b

result = add_numbers(1, 2).get()
```

## Notes

This package is designed like a hosted cloud client (similar to `boto3`):
- developers install the SDK locally
- they write `@remote` code locally
- the SDK connects to a hosted TRON server
- the runtime server and worker code remains private
