"""
TRON - Make Distributed Computing Feel Like Native Python

Key exports:
- @remote: Turn any function into distributed code (NEW - recommended)
- @task: Legacy decorator support
- config(): Configure server URL
- Tron: SDK client (legacy)
- serialize/deserialize: For custom serialization
"""

# New magic layer
from .remote import remote
from .config import set_config_url, get_config
from .magic_future import MagicFuture

# Backward compatibility - old APIs still work
from .decorators import task
from .sdk import Tron
from .serializer import serialize, deserialize
from .client import submit, status

__all__ = [
    # New API (recommended)
    "remote",
    "MagicFuture",
    
    # Configuration
    "config",
    
    # Legacy API (still works)
    "task",
    "Tron",
    "serialize",
    "deserialize",
    "submit",
    "status",
]


def config(url: str = None) -> None:
    """Configure TRON server URL."""
    if url:
        set_config_url(url)
    else:
        print(f"TRON Server: {get_config().url}")

