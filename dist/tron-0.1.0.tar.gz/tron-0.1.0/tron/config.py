"""
TRON Configuration & Auto-Discovery
Auto-detects server, respects environment variables, zero-config ready.
"""

import os
import socket
import time
from typing import Optional


class TronConfig:
    """Centralized TRON configuration with auto-discovery."""

    def __init__(self):
        self.server_url: Optional[str] = None
        self._discovered = False

    @property
    def url(self) -> str:
        """Get TRON server URL with auto-discovery fallback."""
        # 1. Check explicit environment variable
        if env_url := os.getenv("TRON_URL"):
            self.server_url = env_url.rstrip("/")
            return self.server_url

        # 2. Check if already discovered
        if self._discovered and self.server_url:
            return self.server_url

        # 3. Auto-discover on localhost
        self.server_url = self._auto_discover()
        self._discovered = True
        return self.server_url

    @staticmethod
    def _auto_discover() -> str:
        """Auto-discover TRON server on localhost."""
        common_ports = [9000, 8000, 8080, 5000]

        for port in common_ports:
            if TronConfig._is_server_alive(f"http://127.0.0.1:{port}"):
                url = f"http://127.0.0.1:{port}"
                print(f"[TRON] Auto-discovered server at {url}")
                return url

        # Fallback
        default = "http://127.0.0.1:9000"
        print(f"[TRON] No server found. Using default: {default}")
        return default

    @staticmethod
    def _is_server_alive(url: str, timeout: float = 0.5) -> bool:
        """Check if TRON server is responding."""
        try:
            import requests
            resp = requests.get(f"{url}/health", timeout=timeout)
            return resp.status_code == 200
        except Exception:
            return False

    def set_url(self, url: str) -> None:
        """Explicitly set server URL."""
        self.server_url = url.rstrip("/")

    def __repr__(self) -> str:
        return f"<TronConfig url={self.url}>"


# Global config instance
_config = TronConfig()


def get_config() -> TronConfig:
    """Get global TRON config."""
    return _config


def set_config_url(url: str) -> None:
    """Set TRON server URL."""
    _config.set_url(url)
